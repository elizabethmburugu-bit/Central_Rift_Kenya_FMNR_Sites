
# FMNR Dashboard - Central Rift Kenya

## Files in this package:
1. `fmnr_interactive_map.html` - Interactive map showing FMNR sites
2. `fmnr_data.csv` - Raw data in CSV format
3. `instructions.txt` - How to use the dashboard

## How to use:
1. Open `fmnr_interactive_map.html` in any web browser
2. Click on colored circles to see County name and Acres
3. Each county has a unique color:
   - 🔴 Baringo (326.7 acres)
   - 🟢 Elgeyo-Marakwet (261.2 acres)  
   - 🔵 Nakuru (49.2 acres)
   - 🟢 West Pokot (77.5 acres)

## Data Summary:
- Total FMNR Acres: 714.57 acres
- Total Replicates: 1,750
- Female Participants: 727
- Male Participants: 1,021
- Number of Sites: 7

Created: Automatically generated from Google Colab
